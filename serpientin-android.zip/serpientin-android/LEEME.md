# Serpientín Serpientosos — proyecto Android

El juego va dentro de una app Android (WebView) en pantalla completa. Los controles
(joystick/turbo en móvil, ratón/teclado en computadora) se detectan solos.

## Compilar el APK

**Opción A — Android Studio (la más fácil)**
1. Abre Android Studio → *Open* → elige esta carpeta.
2. Espera a que termine la sincronización de Gradle.
3. Menú *Build → Build Bundle(s) / APK(s) → Build APK(s)*.
4. El archivo queda en `app/build/outputs/apk/debug/app-debug.apk`.

**Opción B — línea de comandos** (necesita JDK 17+, Android SDK y Gradle 8.11 o superior)
```
export ANDROID_HOME=/ruta/al/android-sdk
gradle assembleDebug
```

## Instalar en el móvil
Pasa `app-debug.apk` al teléfono y ábrelo (hay que permitir "instalar apps de fuentes
desconocidas"), o conéctalo por USB con depuración activada y usa `adb install app-debug.apk`.

## Notas
- El APK de depuración está firmado con la clave de depuración: sirve para instalar y probar.
  Para publicar en Google Play hace falta un APK/AAB de *release* firmado con tu propia clave.
- El juego está en `app/src/main/assets/index.html`. Si lo cambias, vuelve a compilar.
- El botón "Jugar online" se oculta en la app, porque esa función depende del entorno de Claude.
- Las fuentes (Bowlby One y DM Sans) se descargan de Google Fonts; sin internet se usa una
  fuente del sistema. Récord y skin se guardan en el dispositivo.
